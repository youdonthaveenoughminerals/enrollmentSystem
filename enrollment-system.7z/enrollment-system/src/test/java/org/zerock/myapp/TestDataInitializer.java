package org.zerock.myapp;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;
import org.zerock.myapp.entity.Course;
import org.zerock.myapp.entity.Student;
import org.zerock.myapp.persistence.CourseRepository;
import org.zerock.myapp.persistence.StudentRepository;

@Component
public class TestDataInitializer {

    @Bean
    CommandLineRunner initData(StudentRepository studentRepository, CourseRepository courseRepository) {
        return args -> {
            // 테스트 데이터 추가
            Student student1 = new Student();
            student1.setName("Mangchester Goonited");
            student1.setYear(9);
            studentRepository.save(student1);

            Course course1 = new Course();
            course1.setTitle("Football");
            course1.setProfessor("Prof. Eric Ten Hag");
            course1.setMaxEnrollment(30);
            courseRepository.save(course1);
        };
    }
}

