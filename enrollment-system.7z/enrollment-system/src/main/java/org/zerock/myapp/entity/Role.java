package org.zerock.myapp.entity;

public enum Role {
	STUDENT, PROFESSOR
} // end enum
