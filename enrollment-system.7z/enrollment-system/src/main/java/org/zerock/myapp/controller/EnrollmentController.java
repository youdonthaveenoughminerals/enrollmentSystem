package org.zerock.myapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.zerock.myapp.enrollmentSystem.EnrollmentService;
import org.zerock.myapp.entity.Course;
import org.zerock.myapp.entity.Student;
import org.zerock.myapp.persistence.CourseRepository;
import org.zerock.myapp.persistence.StudentRepository;

import java.util.List;

@RestController
@RequestMapping("/api")
public class EnrollmentController {

    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private CourseRepository courseRepository;

    @Autowired
    private EnrollmentService enrollmentService;

    // 모든 강좌 조회
    @GetMapping("/courses")
    public List<Course> getCourses() {
        return courseRepository.findAll();
    }

    // 수강 신청
    @PostMapping("/enroll")
    public String enrollCourse(@RequestParam Long studentId, @RequestParam Long courseId) {
        Student student = studentRepository.findById(studentId).orElseThrow();
        Course course = courseRepository.findById(courseId).orElseThrow();

        boolean result = enrollmentService.enrollCourse(student, course);
        if (result) {
            studentRepository.save(student);
            courseRepository.save(course);
            return "수강 신청 성공!";
        } else {
            return "수강 신청 실패: 인원이 초과했거나 중복 신청입니다.";
        }
    }

    // 수강 취소
    @DeleteMapping("/enroll")
    public String cancelEnrollment(@RequestParam Long studentId, @RequestParam Long courseId) {
        Student student = studentRepository.findById(studentId).orElseThrow();
        Course course = courseRepository.findById(courseId).orElseThrow();

        boolean result = enrollmentService.cancelEnrollment(student, course);
        if (result) {
            studentRepository.save(student);
            courseRepository.save(course);
            return "수강 취소 성공!";
        } else {
            return "수강 취소 실패: 신청하지 않은 강좌입니다.";
        }
    }
}
