package org.zerock.myapp.enrollmentSystem;

import org.springframework.stereotype.Service;
import org.zerock.myapp.entity.Course;
import org.zerock.myapp.entity.Student;

@Service
public class EnrollmentService {

    public boolean enrollCourse(Student student, Course course) {
        if (course.getStudents().size() >= course.getMaxEnrollment()) {
            return false; // 수강 인원이 초과한 경우
        }
        if (!student.getCourses().contains(course)) {
            student.getCourses().add(course);
            course.getStudents().add(student);
            return true; // 수강 신청 성공
        }
        return false; // 중복 신청 방지
    }

    public boolean cancelEnrollment(Student student, Course course) {
        if (student.getCourses().contains(course)) {
            student.getCourses().remove(course);
            course.getStudents().remove(student);
            return true; // 수강 취소 성공
        }
        return false; // 신청된 강좌가 아닌 경우
    }
}
